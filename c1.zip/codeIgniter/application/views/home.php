<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Henrietta School</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resort Inn Responsive , Smartphone Compatible web template , Samsung, LG, Sony Ericsson, Motorola web design" />
<!-- <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">-->
<link href="<?php echo base_url('assets/boots.css')?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url('assets/respon.css')?>" rel='stylesheet' type='text/css'/>
<link rel="stylesheet" href="<?php echo base_url('assets/fex.css')?>" type="text/css" media="screen" property="" />
<link rel="stylesheet" href="<?php echo base_url('assets/jquery.css')?>" /> 
<link rel="stylesheet" href="<?php echo base_url('assets/style.css')?>" />
<link href="https://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
<!--fonts-->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&display=swap" rel="stylesheet">

<!--//fonts-->
<style>
	*{
		font-family: 'Poppins ', sans-serif;
	}
	h3{
		font-family: 'Poppins', sans-serif;
		font-weight: 400;
	}
	p{
		font-family: 'Poppins', sans-serif;
		font-weight: 1,400;
	}
	.nav li a {
		font-family: 'Poppins', sans-serif;
		font-weight: 400;
	}
</style>
</head>
<body>
<!-- header -->
<div class="banner-top">
			<div class="social-bnr-agileits">
				<ul class="social-icons3">
								<li><a href="https://www.facebook.com/" class="fa fa-facebook icon-border facebook"> </a></li>
								<li><a href="https://twitter.com/" class="fa fa-twitter icon-border twitter"> </a></li>
								<li><a href="https://www.instagram.com/" class="fa fa-instagram icon-border instagram"> </a></li>
							
							</ul>
			</div>
		
			<div class="contact-bnr-w3-agile">
				<ul>
					<li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">Henrietta@gmail.com</a></li>
					<li><i class="fa fa-phone" aria-hidden="true"></i>+81 (14)048-29-10</li>	
				
				
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	<div class="w3_navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<h1><a class="navbar-brand" href="index2.php"><span style="color:white;	font-family: 'Poppins', sans-serif;
		font-weight: 800;">SMA HENRIETTA</span></a></h1>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="menu menu--iris">
						<ul class="nav navbar-nav menu__list">
							<li class="menu__item menu__item--current"><a href="" class="menu__link">Home</a></li>
							<li class="menu__item"><a href="#profil" class="menu__link scroll">Profil</a></li>
							<li class="menu__item"><a href="#about" class="menu__link scroll">About</a></li>
							<li class="menu__item"><a href="#siswa" class="menu__link scroll">Siswa</a></li>
							<li class="menu__item"><a href="#contact" class="menu__link scroll">Contact Us</a></li>
						</ul>
					</nav>
				</div>
			</nav>

		</div>
	</div>
<!-- //header -->
		<!-- banner -->
	<div id="home" class="w3ls-banner">
		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="w3layouts-banner-top">

						<div class="container-fluid banner" style="height:100vh;background:linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://media.timeout.com/images/105861847/image.jpg');background-size:cover;background-position:center;">
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top1">

								</div>	
							</div>
						</div>
					</li>
					
				</ul>
			</div>
			<div class="clearfix"> </div>
			<!--banner Slider starts Here-->
		</div>
		    <div class="thim-click-to-bottom">
				<a href="#about" class="scroll">
					<i class="fa fa-long-arrow-down" aria-hidden="true"></i>
				</a>
			</div>
	</div>	
	<!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Henrietta </h4>
										<img src="" href="" alt=" " class="img-responsive">
										<h5>We don't know what you want. But..</h5>
										<p>Providing guests unique and enchanting views from their rooms with its exceptional amenities, makes Star school one of bests in its kind.Try our food menu, awesome services and friendly staff while you are here.</p>
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
<div id="availability-agileits">
<div class="col-md-12 book-form-left-w3layouts">
</div>

			<div class="clearfix"> </div>
</div>
<!-- /about -->
 	<div class="about-wthree" id="about">
		 <div class="container">	
			 <div class="ab-w3l-spa">
				 <h3 class="title-w3-agileits title-black-wthree">About Our Henrietta</h3> 
					<a href="gallery.html" class="btn btn-default"><ion-icon style="font-size: 16px;" name="albums"></ion-icon>Gallery</a>		 
					<a href="gal.html" class="btn btn-primary"><ion-icon style="font-size: 16px;" name="albums"></ion-icon>Gallery</a>		 
						   <p class="about-para-w3ls">Lorem Ipsum is simply dummy text of the printing and typesetting industry.Sed tempus vestibulum lacus blandit faucibus. Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, at imperdiet urna</p>
						   <img src="images/about.jpg" class="img-responsive" alt="">
						   		<div class="clearfix"> </div>		
											</div>
										</div>
									</div>
							
 	<!-- //about -->



<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- contact -->
<section class="contact-w3ls" id="contact">
	<div class="container">
		<div class="col-lg-6 col-md-6 col-sm-6 contact-w3-agile1">
			<h4>Contact Us</h4>
			<p class="contact-agile1"><strong>Phone :</strong>+81 (14)048-29-10</p>
			<p class="contact-agile1"><strong>Email :</strong> <a href="mailto:name@example.com">Henrietta@gmail.com</a></p>
			<p class="contact-agile1"><strong>Address :</strong> Tsuboyacho, Nakagyō-ku, Kyoto, Kyoto, Prefektur Kyoto</p>
																
			<div class="social-bnr-agileits footer-icons-agileinfo">
				<ul class="social-icons3">
								<li><a href="#" class="fa fa-facebook icon-border facebook"> </a></li>
								<li><a href="#" class="fa fa-twitter icon-border twitter"> </a></li>
								<li><a href="#" class="fa fa-instagram icon-border instagram"> </a></li> 
								
							</ul>
			</div>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22365.829612735368!2d135.72007393971617!3d35.00504223829217!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60010629df92647b%3A0xb2c0d927a148ae26!2sMIMARU%20KYOTO%20HORIKAWA%20ROKKAKU!5e1!3m2!1sid!2sin!4v1667123571742!5m2!1sid!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
		<div class="clearfix"></div>
	</div>
</section>
<!-- /contact -->
			<div class="copy">
		        <p>© 2022 Henrietta . All Rights Reserved</p>
		    </div>
<!--/footer -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- contact form -->
<script src="js/jqBootstrapValidation.js"></script>

<!-- /contact form -->	
<!-- Calendar -->
		<script src="js/jquery-ui.js"></script>
		<script>
				$(function() {
				$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
				});
		</script>
<!-- //Calendar -->
<!-- gallery popup -->
<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script> 
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>
<!-- //gallery popup -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
<!--tabs-->
<script src="js/easy-responsive-tabs.js"></script>
<script>
$(document).ready(function () {
$('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
$('#verticalTab').easyResponsiveTabs({
type: 'vertical',
width: 'auto',
fit: true
});
});
</script>
<!--//tabs-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	
	<div class="arr-w3ls">
	<a href="#home" id="toTop" style="display: block;"> 
	<span id="toTopHover" style="opacity: 0;"> </span>
	<span id="toTopHover" style="opacity: 1;"> </span>
	</a>
	</div>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

</body>
</html>

<!-- 
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Poppins', sans-serif;">
    <div class="container-fluid banner" style="height:100vh;background:linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://scontent.fcgk18-1.fna.fbcdn.net/v/t39.30808-6/310377020_4786850234751588_2436906591982298411_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=730e14&_nc_eui2=AeFCvIALXz4DYd6MIcXX7Z-liEsS2mkrI1-ISxLaaSsjX5cwLVHIzDh5puP9zHoPGAYNWDzAmqBjR_u0VF_FVkLl&_nc_ohc=j2l5MgtdNqEAX_J0gZR&_nc_ht=scontent.fcgk18-1.fna&oh=00_AfBf8ybXqATNXaTaSAUitJObzINWGdGJfPWov7YtRUCytg&oe=63CAA92A');background-size:cover;background-position:center;">
    <nav class="navbar navbar-expand-lg navbar-dark shadow-lg">
        <div class="container-fluid mt-3" style="font-family: 'Poppins', sans-serif;">
            <h1 style="color:white">SMK<span class="" style="color:#BFEAF5">Mutu</span></h1>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link text-white" aria-current="page" href="home"> Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-white" href="about">About</a>
              </li>
            </ul>
        </nav>
        <div class="container-fluid banner-content col-lg-8" style="height:70%;display:flex;justify-content:center;color:white;align-items:center">
            <div>
                <p style="font-family: 'Oswald', sans-serif;font-size:60px" class="text-center d-none d-md-block">
                    SMK 1 MUHAMMADIYAH CIKAMPEK
                </p>
                <form action="">
                    <input type="text" placeholder="      Apa yang engkau cari?" class="form-control mt-5" style="border-radius:50px;height:60px;width:24cm">
                    <button type="submit" class="btn btn-warning btn-block" style="border-radius:30px;position:absolute;right:6cm;top:9.3cm;font-weight:500;height:50px;padding:0 30px;"> Search</button>
                </form>
            </div>
        </div>
    </div>
    <footer class="bg-light mt-5 text-center text-lg-start">
      
    </footer>
</body>
</html> -->