<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title></title>
</head>
<body>
    <div class="container" style="margin-left:60px;margin-top:70px;">
    <div class="row">
    <div class="d-grid">
        <h1>Data Siswa</h1>
        <?php 
        foreach ($siswa as $siswa){
            echo "<p> Nama : ". $siswa['nama']. "</p>";
            echo "<p> kelas : ". $siswa['kelas']. "</p>";
        }
            ?>
    <!-- <table  class="table table-hover table-borderless">
        <tr>
            <thead class="">
            <th scope="col">id</th>
            <th scope="col">name</th>
            <th scope="col">class</th>
            <th scope="col">password</th>
        </thead>
        </tr>
        <tbody>
    <?php foreach ($query as $query) { ?>
        <tr>
            <td><?= $query->id ?></td>
            <td><?= $query->nama ?></td>
            <td><?= $query->kelas ?></td>
            <td><?= $query->pwd ?></td>
        </tr>
  
       <?php } ?>  </tbody>
    </table></div></div> -->
</body>
</html>