<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class data extends CI_Controller {

	public function siswaa()
	{
        //parsing data
        $this->load->database();
        // menampilkan data yg ada di tabel siswa
        $data['siswa'] = $this->db->get('siswa')->result_array();

        $this->load->view('siswa/data', $data);

        // // buat ngecek isi dari variabel
        // var_dump($siswa);

		}
        function insis()
        {
            $this->load->database();

            $data = array(
                'nama' => 'rafa',
                'kelas' => '12',
                'pwd' => '112',

            );
            $this->db->insert('siswa', $data);

        }
	}

