<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// class reg extends CI_Controller {

// 	public function index()
// 	{
// 		//$this->load->view('welcome_message');
//         echo "<h1>mw register??</h1> ";
// 	}

// 	public function signup()
// 	{
// 		//$this->load->view('welcome_message');
//         echo "<h1>mw signup??</h1> ";
// 	}
// }

class reg extends CI_Controller {

	public function index()
	{
		//$this->load->view('welcome_message');
		$this->load->view("reg");
		// echo "Halooo";
	}
}
