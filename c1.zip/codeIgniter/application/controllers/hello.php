<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	// public function data($data)
	// {
	// 	//$this->load->view('');
    //     echo $data;
    //     // ke folder view/welcome_message
	// }

    public function tampil(){
        $data['judul'] = "Halaman utama";
        $data['desc'] = "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi, atque earum quam at, iusto soluta fugit natus provident sed omnis commodi dolorum magnam harum tempore. Perspiciatis praesentium adipisci commodi neque?";

        //parsing data
        $this->load->view('tampil', $data);
    }
}
