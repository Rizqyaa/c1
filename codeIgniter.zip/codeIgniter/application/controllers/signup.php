<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {
    public function index()
	{
		//$this->load->view('welcome_message');
        echo "<h1>mw signup??</h1> ";
	}
    public function sign()
	{
		//$this->load->view('welcome_message');
        echo "<h1>mw ap??</h1> ";
	}
}