<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class coba extends CI_Controller {

	public function kyo()
	{
		// //$this->load->view('welcome_message');
		// $query =$this->db->get("tbtagihan")->result();
		
		// foreach ($query as $query) {
		// 	echo "<p> $query->idpelanggan </p>";

			
			$data['query'] = $this->db->get('datasiswa')->result();

			$this->load->view('viewdata', $data); //parsing data
		}
	}

