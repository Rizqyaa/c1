<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class newc extends CI_Controller {

	public function index()
	{
        echo "<h1> hi</h1>";
	}

    public function nec()
    {
        echo"enih nec";
    }
}
